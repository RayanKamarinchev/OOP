﻿namespace Zoo
{
    class Gorilla : Mammal
    {
        public Gorilla(string name)
            :base(name)
        {

        }
    }
}
