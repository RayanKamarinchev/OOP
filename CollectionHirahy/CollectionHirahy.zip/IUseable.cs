﻿namespace CollectionHirahy
{
    interface IUseable
    {
        int Count { get; set; }
    }
}
