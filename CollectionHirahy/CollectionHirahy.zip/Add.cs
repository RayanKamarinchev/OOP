﻿namespace CollectionHirahy
{
    interface IAddable
    {
        int Add(string item);
    }
}
