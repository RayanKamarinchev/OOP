﻿namespace CollectionHirahy
{
    interface IRemoveable
    {
        string Remove();
    }
}
