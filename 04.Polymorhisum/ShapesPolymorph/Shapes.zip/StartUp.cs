﻿using System;

namespace Shapes_Polymorph
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
