﻿namespace BorderControl
{
    interface IHaveId
    {
        public string Id { get; set; }
    }
}
