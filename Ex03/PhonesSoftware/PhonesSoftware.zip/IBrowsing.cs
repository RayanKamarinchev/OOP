﻿namespace PhonesSoftware
{
    interface IBrowsing
    {
        void Browse();
    }
}
