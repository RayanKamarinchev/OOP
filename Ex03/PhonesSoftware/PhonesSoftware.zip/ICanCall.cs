﻿namespace PhonesSoftware
{
    interface ICanCall
    {
        void Call();
    }
}
